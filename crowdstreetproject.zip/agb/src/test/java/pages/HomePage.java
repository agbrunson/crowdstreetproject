package pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HomePage {
	@FindBy (how = How.XPATH, using = "//a[@href='/invexp/accounts/create-account/']")
	public WebElement createAccountbtn;
	
	@FindBy (how = How.XPATH, using = "//a[@href='/invexp/accounts/create-account/']")
	public List <WebElement> links;
	
	WebDriver driver;
	WebDriverWait wait;
	
	public HomePage (WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		wait = new WebDriverWait(driver, 10);
	}
	
	public void waitForPageLoad () {
			wait.until(ExpectedConditions.elementToBeClickable(links.get(1)));
	}
	
	public void clickCreateAccount () {
		links.get(1).click();
	}
	
	public WebElement getCreateAccount () {
		return links.get(1);
	}
	
}
