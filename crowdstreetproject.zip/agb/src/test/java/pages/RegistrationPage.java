package pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class RegistrationPage {
	@FindBy (how = How.ID, using = "create_account_email")
	WebElement email;
	
	////span[text()="Last Name"]//following::input
	@FindBy (how = How.XPATH, using = "//span[text()='First Name']//following::input")
	WebElement firstName;
	
	@FindBy (how = How.XPATH, using = "//span[text()='Last Name']//following::input")
	WebElement lastName;
	
	@FindBy (how = How.XPATH, using = "//span[text()='Create a Password']//following::input")
	WebElement password;
	
	@FindBy (how = How.XPATH, using = "//span[text()='Confirm Password']//following::input")
	WebElement confirmPassword;
	
	@FindBy (how = How.XPATH, using = "//span[text()='Phone Number']//following::input")
	WebElement phoneNumber;
	
	@FindBy (how = How.CLASS_NAME, using = "_radio_e1a40")
	List <WebElement> radioButtons;
	
	@FindBy (how = How.CLASS_NAME, using = "_check_1fb41")
	List <WebElement> checkboxes;
	
	@FindBy (how = How.CLASS_NAME, using = "recaptcha-checkbox-border")
	WebElement captcha;
	
	@FindBy (how = How.XPATH, using = "//button[text()='Complete your info']")
	WebElement submit;
	
	@FindBy (how = How.XPATH, using = "//span[text()='Complete My Profile']/parent::button")
	WebElement completeProfile;
	
	WebDriver driver;
	WebDriverWait wait;
	
	public RegistrationPage (WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		wait = new WebDriverWait(driver, 10);
	}
	
	public void waitForPageLoad () {
		wait.until(ExpectedConditions.visibilityOf(email));
	}
	
	public void waitForCompleteProfile () {
		wait.until(ExpectedConditions.visibilityOf(completeProfile));
	}
	
	public WebElement getCompleteBtn () {
		return completeProfile;
	}
	
	public void enterEmail (String text) {
		email.clear();
		email.sendKeys(text);
	}
	
	public void enterFirstName (String text) {
		firstName.clear();
		firstName.sendKeys(text);
	}
	
	public void enterLastName (String text) {
		lastName.clear();
		lastName.sendKeys(text);
	}
	
	public void enterPassword (String text) {
		password.clear();
		password.sendKeys(text);
	}
	
	public void enterConfirmPassword (String text) {
		wait.until(ExpectedConditions.visibilityOf(confirmPassword));
		confirmPassword.clear();
		confirmPassword.sendKeys(text);
	}
	
	public void enterPhoneNumber (String text) {
		phoneNumber.clear();
		phoneNumber.sendKeys(text);
	}
	
	public void clickYes () {
		radioButtons.get(0).click();
	}
	
	public void clickNo () {
		radioButtons.get(1).click();
	}
	
	public void clickTOS () {
		checkboxes.get(0).click();
	}
	
	public void clickAck () {
		checkboxes.get(1).click();
	}
	
	public void clickCaptcha () {
		driver.switchTo().frame(0);
		captcha.click();
		driver.switchTo().defaultContent();
	}
	
	public void clickSubmit () {
		submit.click();
	}
	
	public boolean emailVisible () {
		return email.isDisplayed();
	}
}
