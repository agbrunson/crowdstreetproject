package tests;

import java.util.Random;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.RegistrationPage;

public class RegistrationTest {
	
	public WebDriver driver;
	WebDriverWait wait;

	@BeforeClass
	public void beforeClass() {
		System.setProperty("webdriver.chrome.driver", "src\\test\\resources\\chromedriver.exe");
		driver = new ChromeDriver();
		//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		wait = new WebDriverWait(driver, 10);
	}
	
	@AfterClass
	public void afterClass() {
		driver.quit();
	}
	
	public String generateEmail () {
		String email = "";
		Random r = new Random();
		//char c = (char)(r.nextInt(26) + 'a');
		for (int i = 0; i < 5; i++) {
			email = email + (char)(r.nextInt(26) + 'a');
		}
		return email + "@gmail.com";
	}
	
	@Test
	public void registerUser() throws InterruptedException {
		driver.get("https://test.crowdstreet.com/");
		HomePage homePage = new HomePage(driver);
		homePage.waitForPageLoad();
		homePage.clickCreateAccount();
		RegistrationPage regPage = new RegistrationPage(driver);
		regPage.waitForPageLoad();
		regPage.enterEmail(generateEmail());
		regPage.enterFirstName("John");
		regPage.enterLastName("Doe");
		regPage.enterPassword("%wyff#44Z");
		regPage.enterConfirmPassword("%wyff#44Z");
		regPage.enterPhoneNumber("5035551000");
		regPage.clickYes();
		regPage.clickTOS();
		regPage.clickAck();
		Thread.sleep(1000);
		regPage.clickCaptcha();
		regPage.clickSubmit();
		regPage.waitForCompleteProfile();
		Assert.assertTrue(driver.getPageSource().contains("Congrats"));
	}
}
